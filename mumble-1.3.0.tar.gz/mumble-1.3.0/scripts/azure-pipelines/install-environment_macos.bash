#!/bin/bash -ex
#
# Copyright 2019 The Mumble Developers. All rights reserved.
# Use of this source code is governed by a BSD-style license
# that can be found in the LICENSE file at the root of the
# Mumble source tree or at <https://www.mumble.info/LICENSE>.

brew update && brew install pkg-config qt5 boost libogg libvorbis flac libsndfile protobuf openssl ice
